#include "RWLock.h"

RWLock :: RWLock() {

}

void RWLock :: rlock() {
}

void RWLock :: wlock() {
}

void RWLock :: runlock() {
}

void RWLock :: wunlock() {
}
